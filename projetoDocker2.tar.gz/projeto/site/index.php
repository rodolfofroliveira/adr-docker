<?php

$host = 'mercado-db';
$db   = 'mercado';
$user = 'user';
$pass = 'user123';
$charset = 'utf8';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
   PDO::ATTR_ERRMODE                => PDO::ERRMODE_EXCEPTION,
   PDO::ATTR_DEFAULT_FETCH_MODE     => PDO::FETCH_ASSOC
];

try {
   $pdo = new PDO($dsn, $user, $pass, $options);
   $stmt = $pdo->query('SELECT nome FROM frutas');
   echo "<h1> Lista de Frutas </h1><ul>";
   while ($row = $stmt->fetch()) {
      echo "<li>" . htmlspecialchars($row['nome']). "</li>";
   }
   echo "</ul>";
} catch (\PDOException $e) {
   echo "Erro na conexão:" . $e->getMessage();
}

?>
