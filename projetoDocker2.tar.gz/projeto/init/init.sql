CREATE TABLE frutas (
   nome VARCHAR(50) NOT NULL
);

INSERT INTO frutas(nome) VALUES ('Banana'),('Maçã'),('Uva');
